=== Taslabs OAuth ===
Contributors: taslabs
Tags: oauth, authentication, sso, login, taslabs
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrate WordPress with Taslabs ID OAuth server for secure single sign-on authentication.

== Description ==

Taslabs OAuth allows your WordPress site to use Taslabs ID for user authentication. Users can sign in using their verified email addresses through the Taslabs OAuth server.

Features:
* Secure OAuth 2.0 authentication
* Automatic user account creation
* Email verification through Taslabs ID
* Admin settings page
* Shortcode support: [taslabs_login]
* User profile integration

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/taslabs-oauth/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Settings → Taslabs OAuth to configure
4. Test the login button on your WordPress login page

== Frequently Asked Questions ==

= How do I get a Taslabs ID? =
Visit the login page and click "Sign in with Taslabs ID" to create an account.

= Can I customize the login button? =
Yes, use CSS to style the `.taslabs-oauth-btn` class or use the shortcode with custom parameters.

= Where is the callback URL? =
The callback URL is automatically set to: your-site.com/taslabs-oauth-callback

== Screenshots ==

1. Settings page configuration
2. Login button on WordPress login page
3. User profile integration

== Changelog ==

= 1.0.0 =
* Initial release
* OAuth 2.0 integration with Taslabs ID
* Automatic user creation
* Admin settings page
* Shortcode support

== Upgrade Notice ==

= 1.0.0 =
Initial release of Taslabs OAuth integration.