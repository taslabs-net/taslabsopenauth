<?php
// Silence is golden
?>