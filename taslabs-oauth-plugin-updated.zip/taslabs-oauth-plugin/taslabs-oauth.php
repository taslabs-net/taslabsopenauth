<?php
/**
 * Plugin Name: Taslabs OAuth
 * Plugin URI: https://github.com/taslabs-net/taslabsopenauth
 * Description: Integrate WordPress with Taslabs ID OAuth server for single sign-on authentication.
 * Version: 1.0.0
 * Author: Taslabs
 * Author URI: https://taslabs.net
 * License: GPL2
 * Text Domain: taslabs-oauth
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TASLABS_OAUTH_VERSION', '1.0.0');
define('TASLABS_OAUTH_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TASLABS_OAUTH_PLUGIN_PATH', plugin_dir_path(__FILE__));

class TaslabsOAuth {
    
    private $oauth_url = 'https://auth.taslabs.net';
    private $client_id = 'wordpress-site';
    private $redirect_uri;
    
    public function __construct() {
        $this->redirect_uri = rtrim(home_url('/taslabs-oauth-callback'), '/');
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        // Add login button to WordPress login page
        add_action('login_form', array($this, 'add_oauth_button'));
        
        // Handle OAuth callback
        add_action('init', array($this, 'handle_oauth_callback'));
        
        // Add user profile fields
        add_action('show_user_profile', array($this, 'show_profile_fields'));
        add_action('edit_user_profile', array($this, 'show_profile_fields'));
        
        // Add login styles
        add_action('login_enqueue_scripts', array($this, 'login_styles'));
        
        // Add shortcode
        add_shortcode('taslabs_login', array($this, 'login_shortcode'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'admin_menu'));
        
        // Add settings
        add_action('admin_init', array($this, 'admin_init'));
    }
    
    public function activate() {
        // Create options with default values
        add_option('taslabs_oauth_enabled', '1');
        add_option('taslabs_oauth_server_url', $this->oauth_url);
        add_option('taslabs_oauth_client_id', $this->client_id);
        add_option('taslabs_oauth_auto_create_users', '1');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function admin_menu() {
        add_options_page(
            'Taslabs OAuth Settings',
            'Taslabs OAuth',
            'manage_options',
            'taslabs-oauth',
            array($this, 'admin_page')
        );
    }
    
    public function admin_init() {
        register_setting('taslabs_oauth_settings', 'taslabs_oauth_enabled');
        register_setting('taslabs_oauth_settings', 'taslabs_oauth_server_url');
        register_setting('taslabs_oauth_settings', 'taslabs_oauth_client_id');
        register_setting('taslabs_oauth_settings', 'taslabs_oauth_auto_create_users');
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Taslabs OAuth Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('taslabs_oauth_settings'); ?>
                <?php do_settings_sections('taslabs_oauth_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Enable OAuth Login</th>
                        <td>
                            <input type="checkbox" name="taslabs_oauth_enabled" value="1" <?php checked(get_option('taslabs_oauth_enabled'), '1'); ?> />
                            <label>Enable Taslabs ID login button</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">OAuth Server URL</th>
                        <td>
                            <input type="url" name="taslabs_oauth_server_url" value="<?php echo esc_attr(get_option('taslabs_oauth_server_url', $this->oauth_url)); ?>" class="regular-text" />
                            <p class="description">The URL of your Taslabs OAuth server</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Client ID</th>
                        <td>
                            <input type="text" name="taslabs_oauth_client_id" value="<?php echo esc_attr(get_option('taslabs_oauth_client_id', $this->client_id)); ?>" class="regular-text" />
                            <p class="description">Your OAuth client ID</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Auto Create Users</th>
                        <td>
                            <input type="checkbox" name="taslabs_oauth_auto_create_users" value="1" <?php checked(get_option('taslabs_oauth_auto_create_users'), '1'); ?> />
                            <label>Automatically create WordPress accounts for new Taslabs ID users</label>
                        </td>
                    </tr>
                </table>
                
                <div style="background: #f0f8ff; border: 1px solid #0073aa; padding: 15px; margin: 20px 0; border-radius: 4px;">
                    <h3 style="margin-top: 0;">🔗 Integration Info</h3>
                    <p><strong>Callback URL:</strong> <code><?php echo esc_html($this->redirect_uri); ?></code></p>
                    <p><strong>Login Shortcode:</strong> <code>[taslabs_login]</code></p>
                    <p><strong>Status:</strong> 
                        <?php if (get_option('taslabs_oauth_enabled') == '1'): ?>
                            <span style="color: green;">✓ Active</span>
                        <?php else: ?>
                            <span style="color: red;">✗ Disabled</span>
                        <?php endif; ?>
                    </p>
                </div>
                
                <?php submit_button(); ?>
            </form>
            
            <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin-top: 20px;">
                <h2>Usage Instructions</h2>
                <ol>
                    <li><strong>Automatic:</strong> Login button appears on WordPress login page</li>
                    <li><strong>Shortcode:</strong> Use <code>[taslabs_login]</code> anywhere in posts/pages</li>
                    <li><strong>Widget:</strong> Add shortcode to text widgets</li>
                    <li><strong>Theme:</strong> Use <code>do_shortcode('[taslabs_login]')</code> in templates</li>
                </ol>
                
                <h3>Test the Integration</h3>
                <p>Visit your <a href="<?php echo wp_login_url(); ?>" target="_blank">login page</a> to see the Taslabs OAuth button.</p>
            </div>
        </div>
        <?php
    }
    
    public function add_oauth_button() {
        if (get_option('taslabs_oauth_enabled') != '1') {
            return;
        }
        
        $oauth_url = $this->get_oauth_url();
        
        echo '<div style="margin: 20px 0; text-align: center;">';
        echo '<a href="' . esc_url($oauth_url) . '" class="button button-primary taslabs-oauth-btn" style="width: 100%; padding: 12px; text-decoration: none; font-size: 14px;">';
        echo '🔐 Sign in with Taslabs ID';
        echo '</a>';
        echo '<p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">Secure email verification required</p>';
        echo '</div>';
    }
    
    private function get_oauth_url() {
        return get_option('taslabs_oauth_server_url', $this->oauth_url) . '/authorize?' . http_build_query([
            'client_id' => get_option('taslabs_oauth_client_id', $this->client_id),
            'response_type' => 'code',
            'redirect_uri' => $this->redirect_uri,
            'scope' => 'email'
        ]);
    }
    
    public function handle_oauth_callback() {
        if (!isset($_GET['code']) || !str_contains($_SERVER['REQUEST_URI'], 'taslabs-oauth-callback')) {
            return;
        }
        
        if (get_option('taslabs_oauth_enabled') != '1') {
            wp_die('OAuth login is disabled.');
        }
        
        $code = sanitize_text_field($_GET['code']);
        
        // Exchange code for access token
        $token_response = wp_remote_post(get_option('taslabs_oauth_server_url', $this->oauth_url) . '/token', [
            'body' => [
                'grant_type' => 'authorization_code',
                'client_id' => get_option('taslabs_oauth_client_id', $this->client_id),
                'code' => $code,
                'redirect_uri' => $this->redirect_uri
            ],
            'timeout' => 30
        ]);
        
        if (is_wp_error($token_response)) {
            wp_die('OAuth error: ' . $token_response->get_error_message());
        }
        
        $token_data = json_decode(wp_remote_retrieve_body($token_response), true);
        
        if (!isset($token_data['access_token'])) {
            wp_die('OAuth error: Invalid token response');
        }
        
        // Get user info
        $user_response = wp_remote_get(get_option('taslabs_oauth_server_url', $this->oauth_url) . '/userinfo', [
            'headers' => [
                'Authorization' => 'Bearer ' . $token_data['access_token']
            ],
            'timeout' => 30
        ]);
        
        if (is_wp_error($user_response)) {
            wp_die('OAuth error: ' . $user_response->get_error_message());
        }
        
        $user_data = json_decode(wp_remote_retrieve_body($user_response), true);
        
        if (!isset($user_data['email'])) {
            wp_die('OAuth error: No email provided');
        }
        
        // Create or login user
        $user = $this->create_or_login_user($user_data);
        
        if ($user) {
            wp_clear_auth_cookie();
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID);
            
            // Redirect to admin or intended page
            $redirect_to = isset($_COOKIE['taslabs_oauth_redirect']) ? $_COOKIE['taslabs_oauth_redirect'] : admin_url();
            
            wp_safe_redirect($redirect_to);
            exit;
        } else {
            wp_die('Failed to create or login user. Please contact administrator.');
        }
    }
    
    private function create_or_login_user($oauth_user_data) {
        $email = sanitize_email($oauth_user_data['email']);
        $taslabs_id = sanitize_text_field($oauth_user_data['id']);
        
        if (!is_email($email)) {
            return false;
        }
        
        // Check if user exists by email
        $existing_user = get_user_by('email', $email);
        
        if ($existing_user) {
            // Update user meta with Taslabs ID
            update_user_meta($existing_user->ID, 'taslabs_id', $taslabs_id);
            update_user_meta($existing_user->ID, 'taslabs_verified', true);
            update_user_meta($existing_user->ID, 'taslabs_last_login', current_time('mysql'));
            return $existing_user;
        }
        
        // Check if auto-create is enabled
        if (get_option('taslabs_oauth_auto_create_users') != '1') {
            return false;
        }
        
        // Create new user
        $username = sanitize_user(explode('@', $email)[0]);
        $counter = 1;
        $original_username = $username;
        
        // Ensure unique username
        while (username_exists($username)) {
            $username = $original_username . $counter;
            $counter++;
        }
        
        $user_id_wp = wp_create_user($username, wp_generate_password(12, true), $email);
        
        if (is_wp_error($user_id_wp)) {
            error_log('Taslabs OAuth: Failed to create user - ' . $user_id_wp->get_error_message());
            return false;
        }
        
        // Add user meta
        update_user_meta($user_id_wp, 'taslabs_id', $taslabs_id);
        update_user_meta($user_id_wp, 'taslabs_verified', true);
        update_user_meta($user_id_wp, 'taslabs_created', current_time('mysql'));
        update_user_meta($user_id_wp, 'taslabs_last_login', current_time('mysql'));
        
        // Set default role
        $user = new WP_User($user_id_wp);
        $user->set_role(get_option('default_role'));
        
        // Send welcome email (optional)
        wp_new_user_notification($user_id_wp, null, 'user');
        
        return get_user_by('id', $user_id_wp);
    }
    
    public function show_profile_fields($user) {
        $taslabs_id = get_user_meta($user->ID, 'taslabs_id', true);
        $is_verified = get_user_meta($user->ID, 'taslabs_verified', true);
        $created = get_user_meta($user->ID, 'taslabs_created', true);
        $last_login = get_user_meta($user->ID, 'taslabs_last_login', true);
        ?>
        <h3>Taslabs ID Integration</h3>
        <table class="form-table">
            <tr>
                <th><label>Taslabs ID Status</label></th>
                <td>
                    <?php if ($taslabs_id): ?>
                        <div style="background: #d1edff; border: 1px solid #0073aa; padding: 10px; border-radius: 4px;">
                            <p style="margin: 0;"><strong>ID:</strong> <code><?php echo esc_html($taslabs_id); ?></code></p>
                            <?php if ($is_verified): ?>
                                <p style="margin: 5px 0 0 0; color: green;"><strong>✓ Email Verified</strong></p>
                            <?php endif; ?>
                            <?php if ($created): ?>
                                <p style="margin: 5px 0 0 0;"><strong>Account Created:</strong> <?php echo esc_html(date('M j, Y g:i A', strtotime($created))); ?></p>
                            <?php endif; ?>
                            <?php if ($last_login): ?>
                                <p style="margin: 5px 0 0 0;"><strong>Last OAuth Login:</strong> <?php echo esc_html(date('M j, Y g:i A', strtotime($last_login))); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div style="background: #f9f9f9; border: 1px solid #ddd; padding: 10px; border-radius: 4px;">
                            <p style="margin: 0;"><em>Not connected to Taslabs ID</em></p>
                            <p style="margin: 5px 0 0 0;"><a href="<?php echo esc_url($this->get_oauth_url()); ?>">Connect your Taslabs ID</a></p>
                        </div>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <?php
    }
    
    public function login_styles() {
        ?>
        <style>
            .taslabs-oauth-btn {
                background: linear-gradient(135deg, #0051c3 0%, #2C7CB0 100%) !important;
                border: none !important;
                border-radius: 6px !important;
                color: white !important;
                font-weight: 600 !important;
                text-shadow: none !important;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important;
                transition: all 0.3s ease !important;
            }
            .taslabs-oauth-btn:hover {
                background: linear-gradient(135deg, #003d91 0%, #1f5a85 100%) !important;
                transform: translateY(-1px) !important;
                box-shadow: 0 4px 8px rgba(0,0,0,0.15) !important;
                color: white !important;
            }
            .taslabs-oauth-btn:focus {
                box-shadow: 0 0 0 3px rgba(0, 115, 170, 0.25) !important;
            }
        </style>
        <?php
    }
    
    public function login_shortcode($atts) {
        if (get_option('taslabs_oauth_enabled') != '1') {
            return '';
        }
        
        $atts = shortcode_atts([
            'text' => '🔐 Sign in with Taslabs ID',
            'class' => 'button taslabs-oauth-btn',
            'style' => 'display: inline-block; padding: 12px 24px; text-decoration: none; border-radius: 6px; background: linear-gradient(135deg, #0051c3 0%, #2C7CB0 100%); color: white; font-weight: 600; transition: all 0.3s ease;'
        ], $atts);
        
        if (is_user_logged_in()) {
            return '<p style="color: #666;">You are already logged in.</p>';
        }
        
        $oauth_url = $this->get_oauth_url();
        
        return sprintf(
            '<a href="%s" class="%s" style="%s">%s</a>',
            esc_url($oauth_url),
            esc_attr($atts['class']),
            esc_attr($atts['style']),
            esc_html($atts['text'])
        );
    }
}

// Initialize the plugin
new TaslabsOAuth();

// Add plugin action links
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $settings_link = '<a href="options-general.php?page=taslabs-oauth">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
});
?>